export const SERVER_API_URL: string = '/api';
export const HTTP_STATUS_401: number = 401;
