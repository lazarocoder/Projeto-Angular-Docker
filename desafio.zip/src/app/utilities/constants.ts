export const SERVER_API_URL: string = 'http://localhost:8080/api/';
export const HTTP_STATUS_401: number = 401;