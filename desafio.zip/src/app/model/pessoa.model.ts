
export class Pessoa {

  constructor(public id?: number,
    public nome?: string,
    public cpf?: string,
    public sexo?: string,
    public email?: string,
    public dataNascimento?: any,
    public naturalidade?: string,
    public nacionalidade?: string,
    public pessoa?: Pessoa) {

  }

}











